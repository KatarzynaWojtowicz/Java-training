package dziedziczenieZadanie;

public interface Vehicle extends Comparable<Object> {
	String vin();

	void startEngine();
}
