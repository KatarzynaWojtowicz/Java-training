package dziedziczenieZadanie;

public enum Color {
	RED, GREEN, BLACK, BLUE, YELLOW,

}
