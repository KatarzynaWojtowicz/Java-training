package pl.car;

public enum Kolor {
	CZERWONY, CZARNY, SREBRNY, ŻÓŁTY, NIEBIESKI, ZIELONY, BIALY;
}
